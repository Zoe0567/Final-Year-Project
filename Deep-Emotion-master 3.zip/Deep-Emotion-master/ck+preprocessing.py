import os
import pickle

import cv2
import numpy as np
from PIL import Image

label_dir = r'/Users/wangzh/Desktop/MyDoc/DaSiXia/Project1/CK+/Emotion_labels'
image_dir = r'/Users/wangzh/Desktop/MyDoc/DaSiXia/Project1/CK+/cohn-kanade-images'

# Expected images size
purpose_size = 120
face_cascade = cv2.CascadeClassifier('../resources/haarcascade_frontalface_default.xml')


# Crop the facial part
def image_cut(file_name):
    # cv2 read images
    im = cv2.imread(file_name)
    gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    # cv2 Detect the center area of the face
    faces = face_cascade.detectMultiScale(
        gray,
        scaleFactor=1.15,
        minNeighbors=5,
        minSize=(5, 5)
    )

    if len(faces) > 0:
        for (x, y, w, h) in faces:
            # PIL read images
            img = Image.open(file_name)
            # Convert to grayscale image
            img = img.convert("L")
            # Crop the core part of the face
            crop = img.crop((x, y, x + w, y + h))
            # Shrink to 120*120
            crop = crop.resize((purpose_size, purpose_size))
            return crop
    return None


# Convert images to a data matrix
def image_to_matrix(filename):
    # Crop and shrink
    img = image_cut(filename)
    data = img.getdata()
    # normalize to (0,1)
    return np.array(data, dtype=float) / 255.0


# get label
def get_label(file_name):
    f = open(file_name, 'r+')
    line = f.readline()  # only one row
    line_data = line.split(' ')
    label = float(line_data[3])
    f.close()
    # convert 1-7 to 0-6
    return int(label) - 1


# Save the data of the facial core area to the pickle file
def save_picture_data():
    # like [[data1, label1], [data2, label2], ...]
    data_label = []

    # Get a list of subdirectories, like ['S005\001', 'S010\001', 'S010\002', ...]
    dir_list = []
    for root, dirs, _ in os.walk(image_dir):
        for rdir in dirs:
            for _, sub_dirs, _ in os.walk(root + '\\' + rdir):
                for sub_dir in sub_dirs:
                    dir_list.append(rdir + '\\' + sub_dir)
                break
        break

    # Traversing directories to obtain files
    for path in dir_list:
        # handle images
        for root, _, files in os.walk(image_dir + '\\' + path):
            for i in range(0, len(files)):
                if files[i].split('.')[1] == 'png':
                    # Crop the image and convert it into a data matrix
                    img_data = image_to_matrix(root + '\\' + files[i])
                    # Process the corresponding label
                    for lroot, _, lfiles in os.walk(label_dir + '\\' + path):
                        if len(lfiles) > 0:  # picture has label
                            label = get_label(lroot + '\\' + lfiles[0])
                            data_label.append([img_data, label])
                        break
            break
    # Write data to a pkl file
    pkl_file = '../data/data_label_list_120.pkl'
    with open(pkl_file, 'wb') as f:
        pickle.dump(data_label, f)
        f.close()
    print('Picture Data Saved Successfully into:', pkl_file)


if __name__ == '__main__':
    save_picture_data()
    print('\n--------------------------Program Finished---------------------------\n')
