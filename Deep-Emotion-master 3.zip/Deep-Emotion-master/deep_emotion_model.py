import torch
from deep_emotion import Deep_Emotion
import netron
 
torch_model = Deep_Emotion()
 
torch_input = torch.randn(1,48,48)


onnx_program = torch.onnx.dynamo_export(torch_model, torch_input)
onnx_program.save("deep_emotion.onnx")

# torch.onnx.export(torch_model, torch_input, f='Deep_Emotion.onnx')   # Export .onnx file
# netron.start('Deep_Emotion.onnx') # Display structure 
